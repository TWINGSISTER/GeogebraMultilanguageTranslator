function boot(bios, scripts, entry) {
    debugger;
    var script = document.createElement('script');
    script.src = bios;
    script.id = "bios";
    script.type = 'text/javascript';
    script.async = false;
    document.getElementsByTagName('head').item(0).appendChild(script);
       var onloadCall = function() {
        loader(scripts, entry);
    };
    script.onload = onloadCall;
}
//boot([],["./ggbtransl.js","./FileIO.js"],"test();");
boot("./loader.js", [
 //   "./sset.js",
 //   "./Init.js",
 //   "./dictionaryKnownTrans.js",
 //   "./ggbTransFlatting.js",
    "./ggbGlob.js", //tale
//    "./ggbtransl.js",
//    "./FileIO.js",
//    "./Logger.js",
//    "./ggbLatex.js",
//    "./translhtml.js",
//    "./ggbtransl.js",
//    "./LanguageDisplay.js",
//    "./Track.js",
//    "./ggbUtils.js", //"./ctrlRandomize.js",
 //   "./RT.js", "./falsePairs.js",
//"./RedoDisplay.js",
//"./JSON-Patch-master/dist/fast-json-patch.js",
//"./json2xml.js","./xml2json.js"
"./diff-match-patch.js",
"./RedoRecord.js"
], "ggbOnInit()"
//"init();initFalsePair();clickToInstallTranslation();"
);
function RT_R_innerGgbOnInit() {                                     ggbApplet.enableShiftDragZoom(false);
                                      ggbApplet.setValue('gain', 0);
                                     }
function ggbOnInit(){RT_R_innerGgbOnInit();
RT_R_start();
RT_R_init_iterat("numexo");
RT_R_init_tic("Bouton1");
//RT_R_init_tic("juste");
RT_R_init_ok("score");
}